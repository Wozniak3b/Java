package com.wozniak.photo.app;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class PhotoAppApplicationTests {

	@Test
	void contextLoads() {
	}

}
